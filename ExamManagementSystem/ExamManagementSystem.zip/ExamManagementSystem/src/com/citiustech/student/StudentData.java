package com.citiustech.student;

public class StudentData {

	public static int studentRollNumber;
}
